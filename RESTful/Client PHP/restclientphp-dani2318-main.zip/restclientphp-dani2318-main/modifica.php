<?php
    session_start();
    include "moduli.php";
    include "config.php";
    $traccID = $_GET["traccID"];

    $uri = "http://$server:$port/Tracks/$traccID";

    $info = curl($uri);
    
    $id = $info->ID->resource;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifica</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <form class="forms center" action="http://localhost/Giacch%c3%a8/modificaTrack.php?idtrack=<?=$id?>" method="POST">
        <input type="number" name="idAlbum" id="idAlbum" value="<?= $info->Album->resource ?>" placeholder="ID Album"><br>
        <input type="text" name="bytes" id="bytes" value="<?= $info->Bytes ?>" placeholder="bytes"><br>
        <input type="text" name="composer" id="composer" value="<?= $info->Composer ?>" placeholder="composer"><br>
        <input type="number" name="genreID" id="genreID" value="<?=$info->Genre->resource?>" placeholder="ID Genre"><br>
        <input type="number" name="mediaType" id="mediaType" value="<?=$info->MediaType->resource?>" placeholder="Media Type"><br>
        <input type="text" name="milliseconds" id="milliseconds" value="<?=$info->Milliseconds?>" placeholder="Milliseconds"><br>
        <input type="text" name="name" id="name" value="<?=$info->Name?>" placeholder="Name"><br>
        <input type="text" name="unitprice" value="<?=$info->UnitPrice?>" id="unitprice" placeholder="Unit Price"><br>
        <input type="submit" value="Aggiungi"><br>
    </form>
    <a href="http://localhost/Giacch%c3%a8/index.php">home</a>
</body>
</html>