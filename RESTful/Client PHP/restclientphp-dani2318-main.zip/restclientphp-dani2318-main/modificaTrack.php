<?php
    session_start();
    include "config.php";

    $trackID = $_GET["idtrack"];

    echo $trackID;
    $idAlbum = $_POST["idAlbum"];
    $bytes = $_POST["bytes"];
    $Composer = $_POST["composer"];
    $genreID = $_POST["genreID"];
    $mediaType = $_POST["mediaType"];
    $milliseconds = $_POST["milliseconds"];
    $name = $_POST["name"];
    $unitprice = $_POST["unitprice"];
    echo "http://$server:$port/Tracks/$trackID";
    // inizializzo cURL
    $curl = curl_init();

    // imposto il tipo di chiamata html (GET, DELETE, POST, PUT)
    curl_setopt($curl, CURLOPT_URL, "http://$server:$port/Tracks/$trackID");        
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
    curl_setopt($curl, CURLOPT_USERAGENT, 'php client User-Agent');
    curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);

    $track = array(
        'ID' => $trackID,
        'Album' => array('resource' => $idAlbum),
        'Bytes' => $bytes,
        'Composer' => $Composer,
        'Genre' => array('resource' => $genreID),
        'Mediatype' => array('resource' => $mediaType),
        'Milliseconds' => $milliseconds,
        'Name' => $name,
        'UnitPrice' => $unitprice
    );

    $dati = json_encode($track);
    
    curl_setopt($curl, CURLOPT_PUT, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $dati);

    session_abort();
    header("Location:index.php");
?>