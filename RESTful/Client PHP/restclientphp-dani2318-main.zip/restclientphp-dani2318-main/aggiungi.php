<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <form class="forms center" action="./aggiungiTrack.php" method="POST">
        <input type="number" name="idAlbum" id="idAlbum" placeholder="ID Album"><br>
        <input type="text" name="bytes" id="bytes" placeholder="bytes"><br>
        <input type="text" name="Composer" id="composer" placeholder="Composer"><br>
        <input type="number" name="genreID" id="genreID" placeholder="ID Genre"><br>
        <input type="number" name="mediaType" id="mediaType" placeholder="Media Type"><br>
        <input type="text" name="milliseconds" id="milliseconds" placeholder="Milliseconds"><br>
        <input type="text" name="name" id="name" placeholder="Name"><br>
        <input type="text" name="unitprice" id="unitprice" placeholder="Unit Price"><br>
        <input type="submit" value="Aggiungi"><br>
    </form>
    <a href="index.php">home</a>
</body>
</html>