<?php

    include "config.php";

    $idAlbum = $_POST["idAlbum"];
    $bytes = $_POST["bytes"];
    $Composer = $_POST["Composer"];
    $genreID = $_POST["genreID"];
    $mediaType = $_POST["mediaType"];
    $milliseconds = $_POST["milliseconds"];
    $name = $_POST["name"];
    $unitprice = $_POST["unitprice"];

    $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, "http://$server:$port/tracks/");
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($curl, CURLOPT_USERAGENT, 'php client User-Agent');
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
        
    $track = array(
        'Album' => array('resource' => $idAlbum),
        'Bytes' => $bytes,
        'Composer' => $Composer,
        'Genre' => array('resource' => $genreID),
        'Mediatype' => array('resource' => $mediaType),
        'Milliseconds' => $milliseconds,
        'Name' => $name,
        'UnitPrice' => $unitprice
    );
    $dati = json_encode($track);

    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $dati);
    curl_setopt($curl, CURLOPT_HTTPHEADER, array(
      'Content-Type: application/json',
      'Content-Length: ' . strlen($dati))
    );
    
    $result = curl_exec($curl);

    if($result === false)
    {
        echo "Error Number:".curl_errno($curl)."<br>";
        echo "Error String:".curl_error($curl);
    }
    
    $array = json_decode($result, true);
    echo "ID traccia aggiunta:" . $array["ID"]["resource"]; #Ricontrollare ID Risorsa
    echo "<br><a href=\"index.php\">home</a>";
    curl_close($curl);
?>