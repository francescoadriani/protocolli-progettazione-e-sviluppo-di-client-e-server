<?php

      include "config.php";
      
      $id = $_GET["traccID"];

      // inizializzo cURL
      $curl = curl_init();

      // imposto la URL della risorsa remota da scaricare
      curl_setopt($curl, CURLOPT_URL, "http://$server:$port/tracks/$id");
      // evito che il contenuto remoto venga passato a print
      curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
      // imposto il tipo di chiamata html (GET, DELETE, POST, PUT)
      curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "DELETE");
      // Imposto uno user-agent in modo arbitrario
      curl_setopt($curl, CURLOPT_USERAGENT, 'php client User-Agent');
      // Imposto che vengano risolti eventuale redirect
      curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
      
      // chiudo cURL
      curl_close($curl);
?>