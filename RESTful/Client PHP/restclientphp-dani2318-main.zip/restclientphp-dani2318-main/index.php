  
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RESTFUL CLIENT</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php $self = $_SERVER["PHP_SELF"]?>
    <form action="<?= $self ?>" method="GET">
    <?php
            if($_GET){
                if($_GET["visualizza"]){
                    $max = $_GET["visualizza"];
                    echo "<input type=\"number\" name=\"visualizza\" min=\"2\" value=\"$max\" placeholder=\"Elementi da visualizzare\"><br>";
                }
            }else{
                echo "<input type=\"number\" name=\"visualizza\" min=\"2\" value=\"2\" placeholder=\"Elementi da visualizzare\"><br>";
            }

        ?>
        <input type="submit" value="Genera">
    </form>
    <?php
        include "config.php";
        include "moduli.php";
        if($_GET){
            if($_GET["visualizza"]){
                    $max = $_GET["visualizza"];
                    echo "<table>";
                    echo "<tr>";
                        echo "<td><p>TraccID</p></td>";
                        echo "<td><p>TraccName</p></td>";
                        echo "<td><p>AlbumID</p></td>";
                        echo "<td><p>Genere</p></td>";
                        echo "<td><p>MediaType</p></td>";
                        echo "<td><p>Modifica</p></td>";
                    echo "</tr>";

                    for($i = 2;$i<=$max;$i++){
                        $jsonParsed = curl("$server:$port/Tracks/$i");
                        $traccID = $jsonParsed->ID->resource;

                        $genreHref= $jsonParsed->Genre->href;
                        $albumHref= $jsonParsed->Album->href;
                        $mediaTypeHref= $jsonParsed->MediaType->href;

                        $jsonParsedGenre = curl($genreHref);
                        $jsonParsedAlbum = curl($albumHref);
                        $jsonParsedMediaType = curl($mediaTypeHref);

                        $albumID = $jsonParsedAlbum->ID->resource;
                        $trackName = $jsonParsed->Name;
                        $genere = $jsonParsedGenre->Name;
                        $MediaType = $jsonParsedMediaType->Name;

                        echo "<tr>";
                            echo "<td><p>$traccID</p></td>";
                            echo "<td><p>$trackName</p></td>";
                            echo "<td><p>$albumID</p></td>";
                            echo "<td><p>$genere</p></td>";
                            echo "<td><p>$MediaType</p></td>";
                            echo "<td><p><a href=\"modifica.php\\?traccID=$traccID\">Modifica</a></p></td>";
                            echo "<td><p><a href=\"delete.php\\?traccID=$traccID\">Modifica</a></p></td>";
                        echo "</tr>";
                    }
                echo "</table>";
            }
        }

    ?>
    <a href="aggiungi.php">aggiungi nuova traccia</a>
</body>
</html>
