<?php
	if(isset($_POST['album'],$_POST['bytes'],$_POST['composer'],$_POST['genre'],$_POST['mediatype'],$_POST['milliseconds'],$_POST['name'],$_POST['price'])){
		$album = $_POST['album'];
		$bytes = $_POST['bytes'];
		$composer = $_POST['composer'];
		$genre = $_POST['genre'];
		$mediatype = $_POST['mediatype'];
		$milliseconds = $_POST['milliseconds'];
		$name = $_POST['name'];
		$price = $_POST['price'];
		// init curl
		$curlSES = curl_init();
		curl_setopt($curlSES, CURLOPT_URL, "http://10.205.1.215:3333/tracks");
		curl_setopt($curlSES, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curlSES, CURLOPT_CUSTOMREQUEST, "POST");
		curl_setopt($curlSES, CURLOPT_USERAGENT, 'php client User-Agent');
		curl_setopt($curlSES, CURLOPT_FOLLOWLOCATION, true);
		// create track array
		
		$track = array(
			'Album' => array('resource' => $album),
			'Bytes' => $bytes,
			'Composer' => $composer,
			'Genre' => array('resource' => $genre),
			'Mediatype' => array('rsource' => $mediatype),
			'Milliseconds' => $milliseconds,
			'Name' => $name,
			'UnitPrice' => $price
		);
		// send
		
		$data = json_encode($track);
		curl_setopt($curlSES, CURLOPT_POST, true);
        curl_setopt($curlSES, CURLOPT_POSTFIELDS, $data);
        curl_setopt($curlSES, CURLOPT_HTTPHEADER, array(
          'Content-Type: application/json',
          'Content-Length: ' . strlen($data))
        );
		// controllo errori
		
		$result = curl_exec($curlSES);
        if($result === false)
        {
            errorHandler(curl_errno($curlSES),curl_error($curlSES));
        }
        successHandler();
		curl_close($curlSES);
	}
	
	function errorHandler($errorno,$error){
		echo 'error no. '.$errorno.'<br>error: '.$error;
	}
	
	function successHandler($id){
		echo "<span style='color: green'><strong>Traccia Aggiunta</strong></span>";
	}
?>
<!DOCTYPE html>
<html>
	<head>
		
	</head>
	<body>
		<form method=POST action=<?=$_SERVER['REQUEST_URI']?>>
			<select name=album placeholder="album">
				<option value=0> bruh </option>
				<option value=1> bruhvium </option>
				<option value=2> bruhno </option>
				<option value=3> bruhssical </option>
				<option value=4> the bruhs </option>
			</select>
			<input type=number name=bytes min=1 placeholder="bytes">
			<input type=text name=composer placeholder="composer">
			<select name=genre placeholder="genre">
				<option value=0> techno </option>
				<option value=1> classical </option>
				<option value=2> why </option>
				<option value=3> stop </option>
				<option value=4> aaaaaaaaaaaaa </option>
			</select>
			<select name=mediatype placeholder="mediatype">
				<option value=0> mp4 </option>
				<option value=1> mov </option>
				<option value=2> mp3 </option>
				<option value=3> wav </option>
				<option value=4> wmv </option>
			</select>
			<input type=number name=milliseconds min=0 placeholder="milliseconds">
			<input type=text name=name placeholder="name">
			<input type=number name=price placeholder="price"><br>
			<input type=submit value=aggiungi>
		</form>
	</body>
</html>