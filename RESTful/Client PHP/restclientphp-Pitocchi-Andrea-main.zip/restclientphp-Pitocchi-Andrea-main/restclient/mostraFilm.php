<?php
	    // inizializzo cURL
        $curlSES = curl_init();
		function generateSelector($curlSES){
			$select = "<select name='idRisorsa' onChange = 'this.form.submit()'>";
			// imposto la URL della risorsa remota da scaricare
			curl_setopt($curlSES, CURLOPT_URL, "http://10.205.1.215:3333/tracks");
			// evito che il contenuto remoto venga passato a print
			curl_setopt($curlSES, CURLOPT_RETURNTRANSFER, true);
			// imposto il tipo di chiamata html (GET, DELETE, POST, PUT)
			curl_setopt($curlSES, CURLOPT_CUSTOMREQUEST, "GET");
			// Imposto uno user-agent in modo arbitrario
			curl_setopt($curlSES, CURLOPT_USERAGENT, 'php client User-Agent');
			// Imposto che vengano risolti eventuale redirect
			curl_setopt($curlSES, CURLOPT_FOLLOWLOCATION, true);
			
			// eseguo la chiamata e ricevo la risposta
			$result = curl_exec($curlSES);

			// catturare eventuali errori
			if($result === false)
			{
				echo "Error Number:".curl_errno($curlSES)."<br>";
				echo "Error String:".curl_error($curlSES);
			}
			
			// chiudo cURL
			curl_close($curlSES);
			$array = json_decode($result, true);
			if(!isset($_POST['idRisorsa']))
				for($i = 0; $i < sizeof($array); $i++){
					$select .= "<option name=selector value=".$array[$i]["ID"]["resource"].">"; // ID è un array associativo all’interno di un altro array associativo
					$select .= $array[$i]["ID"]["resource"]." ".$array[$i]["Name"]."</option>"; // estraggo il campo Name dall’array associativo
				}
			else
				for($i = 0; $i < sizeof($array); $i++){
					if($array[$i]["ID"]["resource"] != $_POST['idRisorsa'])
						$select .= "<option name=selector value=".$array[$i]["ID"]["resource"].">"; // ID è un array associativo all’interno di un altro array associativo
					else 
						$select .= "<option selected name=selector value=".$array[$i]["ID"]["resource"].">"; // ID è un array associativo all’interno di un altro array associativo
					$select .= $array[$i]["ID"]["resource"]." ".$array[$i]["Name"]."</option>"; // estraggo il campo Name dall’array associativo
				}
			return $select .= '</select>';
		}
		
		function fetchElementData($curlSES,$id){
			curl_setopt($curlSES, CURLOPT_URL, "http://10.205.1.215:3333/tracks");
			curl_setopt($curlSES, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($curlSES, CURLOPT_CUSTOMREQUEST, "GET");
			curl_setopt($curlSES, CURLOPT_USERAGENT, 'php client User-Agent');
			curl_setopt($curlSES, CURLOPT_FOLLOWLOCATION, true);
			$result = curl_exec($curlSES);

			// catturare eventuali errori
			if($result === false)
			{
				echo "Error Number:".curl_errno($curlSES)."<br>";
				echo "Error String:".curl_error($curlSES);
			}
			
			curl_close($curlSES);
			
			$array = json_decode($result,true);
			/*
			schema album
			'Album' => array('resource' => $album),
			'Bytes' => $bytes,
			'Composer' => $composer,
			'Genre' => array('resource' => $genre),
			'Mediatype' => array('rsource' => $mediatype),
			'Milliseconds' => $milliseconds,
			'Name' => $name,
			'UnitPrice' => $price
			$table .= "<tr><td>".$array['ID']['resource']."</td><td>".$array['Album']['resource']."</td><td>".$array['Bytes']."</td><td>".$array['Composer']."</td><td>".$array['Genre']['resource']."</td><td>".$array['Mediatype']['resource']."</td><td>".$array['Milliseconds']."</td><td>".$array['Name']."</td><td>".$array['UnitPrice']."</tr>";
			*/
			$table = "<table><tr><th>Album ID</th><th>Album</th><th>Bytes</th><th>Composer</th><th>Genre</th><th>Mediatype</th><th>Milliseconds</th><th>Name</th><th>Unit Price</th><th colspan=2>operations</th></tr>";
			$array = $array[$id];
			$table .= "<tr><td>".$id."</td><td>".$array['Album']['resource']."</td><td>".$array['Bytes']."</td><td>".$array['Composer']."</td><td>".$array['Genre']['resource']."</td><td>".$array['MediaType']['resource']."</td><td>".$array['Milliseconds']."</td><td>".$array['Name']."</td><td>".$array['UnitPrice']."€</td><td><form method=post action=".$_SERVER['REQUEST_URI']."><input type=hidden value=true name=delete><input type=hidden name=deletionRef value='".$id."'><input type=submit value=delete></form></td><td><form method=post action=modificaFilm.php><input type=hidden name=id value=".$id."><input type=submit value=edit></form></td></tr>";
			$table .= '</table>';
			return $table;
		}
		function init($curlSES){
			if(isset($_POST['idRisorsa'])) 
				return fetchElementData($curlSES,$_POST['idRisorsa']);
		}
		if(isset($_POST['delete'],$_POST['deletionRef'])){
				$curlSES = curl_init();
				curl_setopt($curlSES, CURLOPT_URL, 'http://10.205.1.215:3333/tracks/'.$_POST['deletionRef']);
				curl_setopt($curlSES, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($curlSES, CURLOPT_CUSTOMREQUEST, "DELETE");
				curl_setopt($curlSES, CURLOPT_USERAGENT, 'php client User-Agent');
				curl_setopt($curlSES, CURLOPT_FOLLOWLOCATION, true);
				$result = curl_exec($curlSES);
				if($result === false)
				{
					echo "<br><span style='color: red'>Error Number:".curl_errno($curlSES)."<br>";
					echo "Error String:".curl_error($curlSES).'</span>';
				}
				curl_close($curlSES);
				echo '<br><strong><span style="color: green">Traccia '.$_POST['deletionRef'].' cancellata con successo</strong></span>';
			}
?>
<!doctype = html>
<html>
	<head>
		
	</head>
	<body>
		<form method=post action=<?=$_SERVER['REQUEST_URI']?>>
			<?=generateSelector($curlSES)?>
			<br>
		</form>
		<div id=tabella>
			<?=init($curlSES)?>
		</div>
		<div>
			<form action="aggiungiFilm.php">
				<input type=submit value="Aggiungi Film">
			</form>
		</div>
	</body>
</html>