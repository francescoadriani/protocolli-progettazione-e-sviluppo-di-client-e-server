<?php
	if(isset($_POST['id'])){
		$filmId = $_POST['id'];
		$curlSES = curl_init();
		curl_setopt($curlSES, CURLOPT_URL, "http://10.205.1.215:3333/tracks/".$filmId);
		curl_setopt($curlSES, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curlSES, CURLOPT_CUSTOMREQUEST, "GET");
		curl_setopt($curlSES, CURLOPT_USERAGENT, 'php client User-Agent');
		curl_setopt($curlSES, CURLOPT_FOLLOWLOCATION, true);
		$result = curl_exec($curlSES);
		if($result === false)
		{
			echo "Error Number:".curl_errno($curlSES)."<br>";
			echo "Error String:".curl_error($curlSES);
		}
		curl_close($curlSES);
		$array = json_decode($result, true);
		echo "<form method=POST action=".$_SERVER['REQUEST_URI'].">";
		echo "<input type=number id=album_id name=album value=".$array['Album']['resource'].">";
		echo "<label style=\"vertical-align: top\" for=\"album_id\">Album:</label>";
		echo "<input type=number id=bytes_id name=bytes value=".$array['Bytes'].">";
		echo "<label style=\"vertical-align: top\" for=\"bytes_id\">Bytes:</label>";
		echo "<input type=text id=composer_id name=composer value=".$array['Composer'].">";
		echo "<label style=\"vertical-align: top\" for=\"composer_id\">Composer:</label>";
		echo "<input type=number id=genre_id name=genre value=".$array['Genre']['resource'].">";
		echo "<label style=\"vertical-align: top\" for=\"genre_id\">Genre:</label>";
		echo "<input type=number id=mediatype_id name=mediatype value=".$array['MediaType']['resource'].">";
		echo "<label style=\"vertical-align: top\" for=\"mediatype_id\">Media Type:</label>";
		echo "<input type=number id=milliseconds_id name=milliseconds value=".$array['Milliseconds'].">";
		echo "<label style=\"vertical-align: top\" for=\"milliseconds_id\">Milliseconds:</label>";
		echo "<input type=text id=name_id name=name value=".$array['Name'].">";
		echo "<label style=\"vertical-align: tgop\" for=\"name_id\">Track Name::</label>";
		echo "<input type=number id=price_id name=price value=".$array['UnitPrice'].">";
		echo "<label style=\"vertical-align: top\" for=\"price_id\">Unit Price:</label>";
	} else
		echo "<strong><span style=\"color: red\">Failed to Load ID</span></strong>";
?>